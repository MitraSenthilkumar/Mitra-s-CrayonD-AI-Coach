from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from app.llm_chain import get_chat_response
import traceback

router = APIRouter()

class ChatRequest(BaseModel):
    user_id: str
    message: str

@router.post("/chat")
async def chat(request: ChatRequest):
    try:
        print(f"\n[REQUEST] user_id: {request.user_id}, message: {request.message}")
        response = await get_chat_response(request.user_id, request.message)
        print(f"[RESPONSE] {response}")
        return {"response": response}
    except Exception as e:
        print("[ERROR] An error occurred in /chat route:")
        traceback.print_exc()  # ✅ print full traceback
        raise HTTPException(status_code=500, detail=str(e) or "Unknown error")
 