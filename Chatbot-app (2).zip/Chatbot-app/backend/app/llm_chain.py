from app.vectorstore import get_vectorstore, store_and_query_memory
from app.utils import get_llm
from langchain.schema import HumanMessage

async def get_chat_response(user_id: str, message: str) -> str:
    # Get the vector store (Supabase)
    vectorstore = get_vectorstore()

    # Store the message in vectorstore and query previous history
    context = store_and_query_memory(user_id, message, vectorstore)

    # Get the Gemini LLM model for generating the response
    llm = get_llm()

    # Prepare the messages for the model
    messages = [
        HumanMessage(content=f"You are a helpful assistant. Use this context to answer: {context}"),
        HumanMessage(content=message)
    ]

    # Get the model response
    response = llm(messages)
    return response.content
