import os
from dotenv import load_dotenv
from langchain_community.vectorstores import SupabaseVectorStore
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_core.documents import Document
from supabase import create_client

load_dotenv()

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_SERVICE_ROLE_KEY")

# Create Supabase client
supabase_client = create_client(SUPABASE_URL, SUPABASE_KEY)

# Instantiate Google Generative AI Embeddings
embeddings = GoogleGenerativeAIEmbeddings(
    model="models/embedding-001",
    google_api_key=os.getenv("GEMINI_API_KEY")
)

def get_vectorstore():
    return SupabaseVectorStore(
        client=supabase_client,
        embedding=embeddings,
        table_name="documents"
    )

def store_and_query_memory(user_id: str, message: str, vectorstore) -> str:
    # Store the message in vectorstore
    docs = [Document(page_content=message, metadata={"user_id": user_id})]
    vectorstore.add_documents(docs)

    # Perform similarity search for context
    results = vectorstore.similarity_search(message, k=3)

    return "\n".join([doc.page_content for doc in results])
