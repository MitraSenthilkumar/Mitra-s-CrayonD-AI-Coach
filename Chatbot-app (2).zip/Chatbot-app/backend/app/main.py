from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.chat import router as chat_router

app = FastAPI()

# Allow frontend to communicate with backend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # allow all origins (frontend will need this)
    allow_credentials=True,
    allow_methods=["*"],  # allow all methods (POST, GET)
    allow_headers=["*"],  # allow all headers
)

app.include_router(chat_router, prefix="/api")
